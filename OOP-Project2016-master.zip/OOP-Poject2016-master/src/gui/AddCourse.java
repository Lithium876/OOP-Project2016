package gui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import services.DBConnection;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JTextField;

public class AddCourse {


	private JFrame frmAddCourse;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddCourse window = new AddCourse();
					window.frmAddCourse.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection conn=null;
	private JTextField textField;
	
	public AddCourse() {
		initialize();
		clock();
		conn=DBConnection.dbConnector();
		
	}
	public void load() {
		try {
			AddCourse window = new AddCourse();
			window.frmAddCourse.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void live() {
		try {
			AddCourse window = new AddCourse();
			window.frmAddCourse.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void clock(){
		Thread clock=new Thread()
		{
			public void run()
			{
				try{
					for(;;){
					Calendar now = new GregorianCalendar();
					int day = now.get(Calendar.DAY_OF_MONTH);
					int month=now.get(Calendar.MONTH);
					int year =now.get(Calendar.YEAR);
					/*int seconds = now.get(Calendar.SECOND);
					int minutes=now.get(Calendar.MINUTE);
					int hour=now.get(Calendar.HOUR);
			*/
					//date.setText(month+"/"+day+"/"+year);
					sleep(1000);
					}
				}catch(Exception e){
					
				}
			}
		};
		clock.start();
	}
	public void clear(){
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAddCourse = new JFrame();
		frmAddCourse.setTitle("STAFF MENU");
		frmAddCourse.setResizable(false);
		frmAddCourse.getContentPane().setBackground(new Color(0, 102, 255));
		frmAddCourse.setBounds(100, 100, 757, 476);
		frmAddCourse.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAddCourse.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 153, 255));
		panel.setBounds(12, 12, 212, 421);
		frmAddCourse.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 24));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(39, 0, 130, 44);
		panel.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("View Program Details");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				StudentMenu sm = new StudentMenu();
				frmAddCourse.dispose();	
				sm.load();
			}
		});
		btnNewButton.setBounds(12, 143, 188, 25);
		panel.add(btnNewButton);
		
		JButton btnAddCourse= new JButton("Add Course");
		btnAddCourse.setEnabled(false);
		btnAddCourse.setBounds(12, 195, 188, 25);
		panel.add(btnAddCourse);
		
		JButton btnGenerateFee = new JButton("Generate Fee Breakdown");
		btnGenerateFee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GenerateFee gf = new GenerateFee();
				frmAddCourse.dispose();	
				gf.load();
				
			}
		});
		btnGenerateFee.setBounds(12, 249, 188, 25);
		panel.add(btnGenerateFee);
		
		JButton btnNewButton_1 = new JButton("LOGOUT");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login log = new Login();
				frmAddCourse.dispose();	
				log.run();
			}
		});
		btnNewButton_1.setBounds(39, 384, 117, 25);
		panel.add(btnNewButton_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(0, 153, 255));
		panel_1.setBounds(236, 12, 507, 421);
		frmAddCourse.getContentPane().add(panel_1);
		
		JLabel lblSelectACourses = new JLabel("Select a Course(s) From The Group Below  ");
		lblSelectACourses.setForeground(Color.WHITE);
		lblSelectACourses.setFont(new Font("Dialog", Font.BOLD, 20));
		lblSelectACourses.setBounds(35, 13, 420, 26);
		panel_1.add(lblSelectACourses);
		
		JButton btnSave = new JButton("Save");
		btnSave.setBounds(131, 326, 97, 25);
		panel_1.add(btnSave);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setBounds(282, 326, 97, 25);
		panel_1.add(btnReset);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Math");
		chckbxNewCheckBox.setBounds(70, 132, 113, 25);
		panel_1.add(chckbxNewCheckBox);
		
		JCheckBox chckbxCldd = new JCheckBox("CLDD");
		chckbxCldd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(textField.getText()=="1"){
					chckbxCldd.setEnabled(false);
				}
			}
		});
		
		chckbxCldd.setBounds(201, 178, 113, 25);
		panel_1.add(chckbxCldd);
		
		JCheckBox chckbxEnglish = new JCheckBox("English");
		chckbxEnglish.setBounds(201, 132, 113, 25);
		panel_1.add(chckbxEnglish);
		
		JCheckBox chckbxPe = new JCheckBox("PE");
		chckbxPe.setBounds(342, 132, 113, 25);
		panel_1.add(chckbxPe);
		
		JCheckBox chckbxOop = new JCheckBox("OOP");
		chckbxOop.setBounds(70, 178, 113, 25);
		panel_1.add(chckbxOop);
		
		JCheckBox chckbxStats = new JCheckBox("Stats");
		chckbxStats.setBounds(342, 178, 113, 25);
		panel_1.add(chckbxStats);
		
		JCheckBox chckbxEthics = new JCheckBox("Ethics");
		chckbxEthics.setBounds(70, 228, 113, 25);
		panel_1.add(chckbxEthics);
		
		JCheckBox chckbxArt = new JCheckBox("Art");
		chckbxArt.setBounds(201, 228, 113, 25);
		panel_1.add(chckbxArt);
		
		JLabel lblNewLabel_1 = new JLabel("Program Enrolled:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(47, 70, 146, 20);
		panel_1.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// the number were used for testing so just change them to the programs need
				//enables first 4 checkboxes
				if(textField.getText().equals("1")){
					
					chckbxEthics.setEnabled(false);
					chckbxArt.setEnabled(false);
					chckbxStats.setEnabled(false);
					chckbxCldd.setEnabled(false);
					
				}
				//enables first 6 checkboxes
				else if(textField.getText().equals("2")){
					chckbxStats.setEnabled(true);
					chckbxCldd.setEnabled(true);
					chckbxEthics.setEnabled(false);
					chckbxArt.setEnabled(false);
				}
				// Enables all checkboxes
				else if(textField.getText().equals("3")){
					chckbxStats.setEnabled(true);
					chckbxCldd.setEnabled(true);
					chckbxEthics.setEnabled(true);
					chckbxArt.setEnabled(true);
				}
				
			}
		});
		textField.setBounds(198, 68, 116, 22);
		panel_1.add(textField);
		textField.setColumns(10);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(60, 120, 407, 145);
		panel_1.add(panel_2);
		
	}
}