package presentation;

import gui.Login;

public class driver {

	public static void main(String[] args) {
		Login start =new Login();
		start.run();
	}
}